package Controller;

import Controller.Helper.LoginHelper;
import Model.Usuario;
import View.Login;
import View.Menu;
import javax.swing.JOptionPane;

public class LoginController {

    private final Login view;
    private final LoginHelper helper;

    public LoginController(Login view) {
        this.view = view;
        this.helper = new LoginHelper(view);
    }

    // Exemplo de uma tarefa genérica
    public void fizTarefa() {
        System.out.println("Ação executada pelo Controller.");
        view.exibeMensagem("Ação executada com sucesso!");
    }

    // Realiza a validação do login
    public void entrarNoSistema() {
        Usuario usuario = helper.obterModelo();

        String nome = usuario.getNome();
        String senha = usuario.getSenha();

        if (nome == null || nome.trim().isEmpty()
                || senha == null || senha.isEmpty()) {

            view.exibeMensagem(
                    "Preencha o usuário e a senha."
            );
            return;
        }

        /*
         * Validação temporária para testar o fluxo.
         * Depois, substitua pela consulta ao banco de dados.
         */
        if (nome.equals("admin") && senha.equals("123")) {
            JOptionPane.showMessageDialog(
                    view,
                    "Login realizado com sucesso!"
            );

            Menu menu = new Menu();
            menu.setVisible(true);
            view.dispose();

        } else {
            view.exibeMensagem(
                    "Usuário ou senha inválidos."
            );
            helper.limparTela();
        }
    }
}