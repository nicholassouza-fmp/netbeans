import Model.Agendamento;
import Model.Cliente;
import Model.Pessoa;
import Model.Servico;
import Model.Usuario;

public class Main {

    public static void main(String[] args) {

        // Teste da classe Servico
        Servico servico = new Servico(1, "Barba", 30.0f);

        System.out.println("=== SERVIÇO ===");
        System.out.println("Descrição: " + servico.getDescricao());
        System.out.println("Valor: " + servico.getValor());


        // Teste do construtor reduzido de Cliente
        Cliente cliente = new Cliente(
                1, "Jorge", "Rua Tesla, 95", "95445866"
        );

        System.out.println("\n=== CLIENTE ===");
        System.out.println("Nome: " + cliente.getNome());
        System.out.println("Endereço: " + cliente.getEndereco());


        // Teste do construtor reduzido de Usuario
        Usuario usuario = new Usuario(1, "Barbeiro", "senha");

        System.out.println("\n=== USUÁRIO ===");
        System.out.println("Nome: " + usuario.getNome());
        System.out.println("Senha: " + usuario.getSenha());


        // Teste dos construtores completos
        Cliente clienteCompleto = new Cliente(
                2,
                "Maria",
                'F',
                "15/06/2000 00:00",
                "48999999999",
                "maria@email.com",
                "123456789",
                "Rua das Flores, 100",
                "88000000"
        );

        Usuario usuarioCompleto = new Usuario(
                2,
                "Carlos",
                'M',
                "10/08/1995 00:00",
                "48988888888",
                "carlos@email.com",
                "987654321",
                "abc123",
                "Administrador"
        );

        System.out.println("\n=== TESTE DE HERANÇA ===");
        System.out.println("Cliente: " + clienteCompleto.getNome());
        System.out.println("Sexo: " + clienteCompleto.getSexo());
        System.out.println("Telefone: " + clienteCompleto.getTelefone());

        System.out.println("Usuário: " + usuarioCompleto.getNome());
        System.out.println("Acesso: " + usuarioCompleto.getNivelAcesso());


        // Teste de Agendamento
        Agendamento agendamento = new Agendamento(
                1,
                cliente,
                servico,
                30.0f,
                "25/03/2024 11:20",
                "Cliente agendou serviço de barba"
        );

        System.out.println("\n=== AGENDAMENTO ===");
        System.out.println("ID: " + agendamento.getId());
        System.out.println("Cliente: "
                + agendamento.getCliente().getNome());
        System.out.println("Serviço: "
                + agendamento.getServico().getDescricao());
        System.out.println("Valor: " + agendamento.getValor());
        System.out.println("Data: " + agendamento.getData());
        System.out.println("Observação: "
                + agendamento.getObservacao());


        // Pessoa é abstrata, mas pode referenciar um Cliente
        Pessoa pessoa = clienteCompleto;

        System.out.println("\n=== PESSOA ===");
        System.out.println("Nome: " + pessoa.getNome());
    }
}