package Controller.Helper;

import Model.Agendamento;
import Model.Cliente;
import Model.Servico;
import View.Agenda;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

public class AgendaHelper implements IHelper {

    private final Agenda view;

    public AgendaHelper(Agenda view) {
        this.view = view;
    }

    public void preencherTabela(ArrayList<Agendamento> agendamentos) {
        DefaultTableModel modelo = (DefaultTableModel) view.getTabela().getModel();
        modelo.setRowCount(0);

        for (Agendamento agendamento : agendamentos) {
            modelo.addRow(new Object[]{
                agendamento.getId(),
                agendamento.getCliente(),
                agendamento.getServico(),
                agendamento.getValor(),
                agendamento.getDataFormatada(),
                agendamento.getHoraFormatada(),
                agendamento.getObservacao()
            });
        }
    }

    public void preencherCliente(ArrayList<Cliente> clientes) {
        DefaultComboBoxModel<Cliente> modelo = new DefaultComboBoxModel<>();
        for (Cliente cliente : clientes) modelo.addElement(cliente);
        view.getComboCliente().setModel(modelo);
    }

    public void preencherServico(ArrayList<Servico> servicos) {
        DefaultComboBoxModel<Servico> modelo = new DefaultComboBoxModel<>();
        for (Servico servico : servicos) modelo.addElement(servico);
        view.getComboServico().setModel(modelo);
    }

    public Servico obterServico() {
        return (Servico) view.getComboServico().getSelectedItem();
    }

    public void setarValor(float valor) {
        view.getCampoValor().setText(String.valueOf(valor));
    }

    @Override
    public Agendamento obterModelo() {
        Cliente cliente = (Cliente) view.getComboCliente().getSelectedItem();
        Servico servico = obterServico();
        String valorTexto = view.getCampoValor().getText().trim().replace(',', '.');
        String data = view.getCampoData().getText().trim();
        String hora = view.getCampoHora().getText().trim();
        String observacao = view.getCampoObservacao().getText().trim();

        if (cliente == null || servico == null || valorTexto.isEmpty()
                || data.isEmpty() || hora.isEmpty()) {
            throw new IllegalArgumentException("Preencha cliente, serviço, data e hora.");
        }

        float valor = Float.parseFloat(valorTexto);
        String dataHora = data + " " + hora;
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        formato.setLenient(false);
        try {
            formato.parse(dataHora);
        } catch (ParseException ex) {
            throw new IllegalArgumentException("Data ou hora inválida. Use dd/MM/yyyy e HH:mm.");
        }
        return new Agendamento(0, cliente, servico, valor, dataHora, observacao);
    }

    @Override
    public void limparTela() {
        view.getComboCliente().setSelectedIndex(-1);
        view.getComboServico().setSelectedIndex(-1);
        view.getCampoValor().setText("");
        view.getCampoData().setText("");
        view.getCampoHora().setText("");
        view.getCampoObservacao().setText("");
    }
}
