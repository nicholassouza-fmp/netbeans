package Controller;

import Controller.Helper.AgendaHelper;
import Model.Agendamento;
import Model.Cliente;
import Model.Servico;
import Model.DAO.AgendamentoDAO;
import Model.DAO.ClienteDAO;
import Model.DAO.ServicoDAO;
import View.Agenda;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AgendaController {

    private final Agenda view;
    private final AgendaHelper helper;

    public AgendaController(Agenda view) {
        this.view = view;
        this.helper = new AgendaHelper(view);
    }

    public void iniciar() {
        atualizaTabela();
        atualizaCliente();
        atualizaServico();
        atualizaValor();
    }

    public void atualizaTabela() {
        ArrayList<Agendamento> agendamentos = new AgendamentoDAO().selectAll();
        helper.preencherTabela(agendamentos);
    }

    public void atualizaCliente() {
        ArrayList<Cliente> clientes = new ClienteDAO().selectAll();
        helper.preencherCliente(clientes);
    }

    public void atualizaServico() {
        ArrayList<Servico> servicos = new ServicoDAO().selectAll();
        helper.preencherServico(servicos);
    }

    public void atualizaValor() {
        Servico servico = helper.obterServico();
        if (servico != null) helper.setarValor(servico.getValor());
        else helper.setarValor(0);
    }

    public void agendar() {
        try {
            Agendamento agendamento = helper.obterModelo();
            new AgendamentoDAO().insert(agendamento);
            atualizaTabela();
            helper.limparTela();
            JOptionPane.showMessageDialog(view, "Agendamento cadastrado com sucesso!");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage(), "Atenção", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view,
                    "Não foi possível cadastrar. Confira a data (dd/MM/yyyy) e a hora (HH:mm).",
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
