package Model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Agendamento {
    private int id;
    private Cliente cliente;
    private Servico servico;
    private float valor;
    private Date data;
    private String observacao;

    public Agendamento(int id, Cliente cliente, Servico servico,
                       float valor, String data) {
        this.id = id;
        this.cliente = cliente;
        this.servico = servico;
        this.valor = valor;
        converterData(data);
    }

    public Agendamento(int id, Cliente cliente, Servico servico,
                       float valor, String data, String observacao) {
        this(id, cliente, servico, valor, data);
        this.observacao = observacao;
    }

    // Compatibilidade com os objetos de exemplo do Banco.java:
    // data e hora são recebidas separadamente.
    public Agendamento(int id, Cliente cliente, Servico servico,
                       float valor, String data, String hora,
                       String observacao) {
        this(id, cliente, servico, valor, data + " " + hora, observacao);
    }

    private void converterData(String dataTexto) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        formato.setLenient(false);
        try {
            this.data = formato.parse(dataTexto);
        } catch (ParseException ex) {
            Logger.getLogger(Agendamento.class.getName())
                  .log(Level.SEVERE, "Data de agendamento inválida: " + dataTexto, ex);
        }
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Servico getServico() { return servico; }
    public void setServico(Servico servico) { this.servico = servico; }

    public float getValor() { return valor; }
    public void setValor(float valor) { this.valor = valor; }

    public Date getData() { return data; }
    public void setData(Date data) { this.data = data; }

    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    public String getDataFormatada() {
        if (data == null) return "";
        return new SimpleDateFormat("dd/MM/yyyy").format(data);
    }

    public String getHoraFormatada() {
        if (data == null) return "";
        return new SimpleDateFormat("HH:mm").format(data);
    }

}
