package barbeariashop;

import Model.DAO.Banco;
import View.Login;

public class BarbeariaShop {

    public static void main(String[] args) {
        try {
            Banco.inicia();

            java.awt.EventQueue.invokeLater(() -> {
                Login login = new Login();
                login.setLocationRelativeTo(null);
                login.setVisible(true);
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}