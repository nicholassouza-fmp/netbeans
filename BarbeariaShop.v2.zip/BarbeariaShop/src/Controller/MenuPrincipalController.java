package Controller;

import View.MenuPrincipal;
import View.Agenda;

public class MenuPrincipalController {

    private final MenuPrincipal view;

    public MenuPrincipalController(MenuPrincipal view) {
        this.view = view;
    }

    public void abrirAgenda() {
        Agenda agenda = new Agenda();
        agenda.setLocationRelativeTo(null);
        agenda.setVisible(true);

        view.dispose();
    }
}