
package Controller;

import Controller.Helper.LoginHelper;
import Model.Usuario;
import Model.DAO.UsuarioDAO;
import View.Login;
import View.MenuPrincipal;

public class LoginController {

    private final Login view;
    private final LoginHelper helper;
    private final UsuarioDAO usuarioDAO;

    public LoginController(Login view) {
        this.view = view;
        this.helper = new LoginHelper(view);
        this.usuarioDAO = new UsuarioDAO();
    }

    public void entrarNoSistema() {
        Usuario usuarioDigitado = helper.obterModelo();

        String nome = usuarioDigitado.getNome();
        String senha = usuarioDigitado.getSenha();

        if (nome == null || nome.trim().isEmpty()
                || senha == null || senha.isEmpty()) {
            view.exibeMensagem("Preencha o usuário e a senha.");
            return;
        }

        Usuario usuarioEncontrado =
                usuarioDAO.selectPorNomeESenha(usuarioDigitado);

        if (usuarioEncontrado != null) {
            view.exibeMensagem("Login realizado com sucesso!");

            MenuPrincipal menu = new MenuPrincipal();
            menu.setLocationRelativeTo(null);
            menu.setVisible(true);

            view.dispose();

        } else {
            view.exibeMensagem("Usuário ou senha inválidos.");
            helper.limparTela();
            return;
        }
    }
}
