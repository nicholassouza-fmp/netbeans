package Controller.Helper;

import Model.Usuario;
import View.Login;

public class LoginHelper {

    private final Login view;

    public LoginHelper(Login view) {
        this.view = view;
    }

    // Obtém os dados digitados e cria um Usuario
    public Usuario obterModelo() {
        String nome = view.getTxtUsuario().getText();
        String senha = new String(
                view.getTxtSenha().getPassword()
        );

        return new Usuario(0, nome, senha);
    }

    // Preenche a tela com os dados de um Usuario
    public void setarModelo(Usuario usuario) {
        view.getTxtUsuario().setText(usuario.getNome());
        view.getTxtSenha().setText(usuario.getSenha());
    }

    // Limpa os campos da tela
    public void limparTela() {
        view.getTxtUsuario().setText("");
        view.getTxtSenha().setText("");
    }
}