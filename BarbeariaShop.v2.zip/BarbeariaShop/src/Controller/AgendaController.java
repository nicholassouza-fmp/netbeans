package Controller;

import View.Agenda;

public class AgendaController {
    private final Agenda view;

    public AgendaController(Agenda view) {
        this.view = view;
    }
}
